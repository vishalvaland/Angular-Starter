export class Product {
    id: number;
    name: string;
    description: string; 
    code: number;
    image:File;
    price:number;
    category:string;
}
