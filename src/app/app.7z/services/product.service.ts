import { Product } from './../models/product';
import { environment } from './../../environments/environment'; 
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

constructor(
  private http:HttpClient,
) { }

// create(selectedFile){

//   // console.log(selectedFile);
//    return this.http.post<any>(`${environment.apiUrl}productTwo`, this.selectedFile)
// }

}


