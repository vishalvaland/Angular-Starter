import { environment } from './../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { first, map, tap } from 'rxjs/operators';
import { ProductService } from './../services/product.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html'
})
export class ProductComponent implements OnInit {
  productForm:FormGroup;
  submitted=false;
  alertSwitch = false;
  alertMessage :any;
  alertClass :string;
  selectedFile: File;

  constructor(
    private http:HttpClient,
    private formBuilder:FormBuilder,
    private productService:ProductService

  ) { }

  ngOnInit(): void {
    this.productForm=this.formBuilder.group({
      // name:['', Validators.required],
      // code:['', Validators.required],
      // description:[''],
      // image:null,
      // price:['',Validators.required],
      // category:['', Validators.required]

      name:[''],
      code:[''],
      description:[''],
      image:null,
      price:[''],
      category:['']

    });
  }

  get f() { return this.productForm.controls; }
  @ViewChild("fileInput") fileInput:ElementRef;    

    onFileChange(event) {
      if(event.target.files.length > 0) {
        let files = event.target.files[0];
        this.selectedFile=files;
        this.http.post<any>(`${environment.apiUrl}productTwo`, this.selectedFile)
        // this.productForm=this.formBuilder.group({ 
        //   image:file, 
        // });
        // this.productForm.get('image').setValue(file);
        // console.log(this.selectedFile);
      }
    }
    // private prepareSave(): any {
    //   let input = new FormData();
    //   input.append('name',   this.productForm.get('name').value);
    //   input.append('avatar', this.form.get('avatar').value);
    //   return input;
    // }
    onsubmit() { 
      
      // let fi = this.fileInput.nativeElement;
      // let imageFile = fi.files[0];
      // this.productForm.get('image').setValue(imageFile);
     // console.log(imageFile);
      
      // let imagedata = new FormData();
      // imagedata.append("file", imageFile, imageFile);  
      

      this.submitted=true;
      if(this.productForm.invalid){
        return true;
      }
      this.http.post<any>(`${environment.apiUrl}productTwo`, this.selectedFile)
      

      // this.productService.create(this.selectedFile)       
      // .pipe(        
      //   // map(image => ({...image, image: imageFile})),
      //     // tap(selectedFile => console.log(selectedFile)),
      //   first())
      //   .subscribe(data => { 
      //       this.alertSwitch=true;
      //       this.alertClass='success';
      //       this.alertMessage='Registration successful'; 
      //     },
      //     error => {
      //       this.alertSwitch=true;
      //       this.alertClass='danger';
      //       this.alertMessage=error.error;  
      //     } 
      // );
      

    }

 
   

}
